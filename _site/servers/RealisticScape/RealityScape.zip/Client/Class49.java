public final class Class49
{

    public Class49()
    {
    }

    int anInt811;
    int anInt812;
    int anInt813;
    public Class30_Sub2_Sub4 aClass30_Sub2_Sub4_814;
    public int anInt815;
    byte aByte816;
}
