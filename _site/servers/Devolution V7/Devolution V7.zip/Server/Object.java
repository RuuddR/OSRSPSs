public class Object {
	public int id, x, y, type;

	public Object(int id, int x, int y, int type) {
		this.id = id;
		this.x = x;
		this.y = y;
		this.type = type;
	}
}