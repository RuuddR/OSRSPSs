#!/bin/bash

cd bin && java -Xmx1024M server
