final class Class47
{

    Class47()
    {
    }

    int anInt787;
    int anInt788;
    int anInt789;
    int anInt790;
    int anInt791;
    int anInt792;
    int anInt793;
    int anInt794;
    int anInt795;
    int anInt796;
    int anInt797;
    int anInt798;
    int anInt799;
    int anInt800;
    int anInt801;
    int anInt802;
    int anInt803;
    int anInt804;
}
