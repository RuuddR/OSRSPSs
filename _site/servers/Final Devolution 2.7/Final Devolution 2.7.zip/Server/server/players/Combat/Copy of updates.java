package server.players.Combat;



import server.*;
import server.util.*;
import server.npcs.*;
import server.world.*;
import server.players.*;
import server.players.Combat.*;

public class updates {

	private client c;
	public updates(client client) {
		this.c = client;
	}
	public void runUpdate(client i) {
		if (i == null) {
			return;
		}
	}

}