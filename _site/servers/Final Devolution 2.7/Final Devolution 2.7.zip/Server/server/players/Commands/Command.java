package server.players.Commands;

import server.players.Commands.*;
import server.players.*;



public interface Command {


	public void execute(client client, String command);


}
