// Decompiled by Jad v1.5.8f. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 


public class Class5
{

    public Class5()
    {
    }

    public int anInt113;
    public int anInt114;
    public int anInt115;
    public int anInt116;
    public Class50_Sub1_Sub4 aClass50_Sub1_Sub4_117;
    public int anInt118;
    public int anInt119;
    public int anInt120;
    public int anInt121;
    public int anInt122;
    public int anInt123;
    public int anInt124;
    public int anInt125;
    public byte aByte126;
}
