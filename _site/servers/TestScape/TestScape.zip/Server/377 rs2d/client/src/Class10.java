// Decompiled by Jad v1.5.8f. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 


public class Class10
{

    public Class10()
    {
    }

    public int anInt173;
    public int anInt174;
    public int anInt175;
    public Class50_Sub1_Sub4 aClass50_Sub1_Sub4_176;
    public Class50_Sub1_Sub4 aClass50_Sub1_Sub4_177;
    public Class50_Sub1_Sub4 aClass50_Sub1_Sub4_178;
    public int anInt179;
    public int anInt180;
}
