// Decompiled by Jad v1.5.8f. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 

import sign.signlink;

public class Class50_Sub1_Sub4 extends Class50_Sub1
{

    public void method560(int i, int j, int k, int l, int i1, int j1, int k1, 
            int l1, int i2)
    {
        Class50_Sub1_Sub4_Sub4 class50_sub1_sub4_sub4 = method561(aByte1472);
        if(class50_sub1_sub4_sub4 != null)
        {
            anInt1475 = ((Class50_Sub1_Sub4) (class50_sub1_sub4_sub4)).anInt1475;
            class50_sub1_sub4_sub4.method560(i, j, k, l, i1, j1, k1, l1, i2);
        }
    }

    public Class50_Sub1_Sub4_Sub4 method561(byte byte0)
    {
        if(byte0 != 3)
            aBoolean1473 = !aBoolean1473;
        return null;
    }

    public Class50_Sub1_Sub4()
    {
        aBoolean1473 = true;
        anInt1475 = 1000;
    }

    public static byte aByte1472 = 3;
    public boolean aBoolean1473;
    public Class40 aClass40Array1474[];
    public int anInt1475;
    public static boolean aBoolean1476;

}
