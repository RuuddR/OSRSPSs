// Decompiled by Jad v1.5.8f. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 


public class Class35
{

    public Class35()
    {
    }

    public int anInt603;
    public int anInt604;
    public int anInt605;
    public int anInt606;
    public int anInt607;
    public Class50_Sub1_Sub4 aClass50_Sub1_Sub4_608;
    public int anInt609;
    public byte aByte610;
}
