// Decompiled by Jad v1.5.8f. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 


public class Class3
{

    public Class3(int i, int j, int k, int l, int i1, int j1, boolean flag)
    {
        aBoolean100 = true;
        anInt95 = i;
        anInt96 = j;
        anInt97 = k;
        anInt98 = l;
        anInt99 = i1;
        anInt101 = j1;
        aBoolean100 = flag;
    }

    public int anInt95;
    public int anInt96;
    public int anInt97;
    public int anInt98;
    public int anInt99;
    public boolean aBoolean100;
    public int anInt101;
}
