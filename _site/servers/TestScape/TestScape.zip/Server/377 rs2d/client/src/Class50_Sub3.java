// Decompiled by Jad v1.5.8f. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 


public class Class50_Sub3 extends Class50
{

    public Class50_Sub3(int i, int j, int k)
    {
        aBoolean1396 = false;
        aClass5Array1408 = new Class5[5];
        anIntArray1409 = new int[5];
        anInt1400 = anInt1397 = i;
        anInt1398 = j;
        anInt1399 = k;
    }

    public boolean aBoolean1396;
    public int anInt1397;
    public int anInt1398;
    public int anInt1399;
    public int anInt1400;
    public Class3 aClass3_1401;
    public Class20 aClass20_1402;
    public Class44 aClass44_1403;
    public Class35 aClass35_1404;
    public Class28 aClass28_1405;
    public Class10 aClass10_1406;
    public int anInt1407;
    public Class5 aClass5Array1408[];
    public int anIntArray1409[];
    public int anInt1410;
    public int anInt1411;
    public boolean aBoolean1412;
    public boolean aBoolean1413;
    public boolean aBoolean1414;
    public int anInt1415;
    public int anInt1416;
    public int anInt1417;
    public int anInt1418;
    public Class50_Sub3 aClass50_Sub3_1419;
}
