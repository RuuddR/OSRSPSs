// Decompiled by Jad v1.5.8f. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 


public class Class40
{

    public Class40()
    {
    }

    public int anInt693;
    public int anInt694;
    public int anInt695;
    public int anInt696;
}
