// Decompiled by Jad v1.5.8f. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 


public class Class50_Sub2 extends Class50
{

    public Class50_Sub2()
    {
        anInt1390 = -1;
    }

    public int anInt1384;
    public int anInt1385;
    public int anInt1386;
    public int anInt1387;
    public int anInt1388;
    public int anInt1389;
    public int anInt1390;
    public int anInt1391;
    public int anInt1392;
    public int anInt1393;
    public int anInt1394;
    public int anInt1395;
}
