// Decompiled by Jad v1.5.8f. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 

import sign.signlink;

public class Class50_Sub1_Sub4_Sub1 extends Class50_Sub1_Sub4
{

    public Class50_Sub1_Sub4_Sub4 method561(byte byte0)
    {
        if(byte0 != 3)
            anInt1551 = -358;
        Class16 class16 = Class16.method212(anInt1550);
        return class16.method220(anInt1552);
    }

    public Class50_Sub1_Sub4_Sub1()
    {
    }

    public int anInt1550;
    public int anInt1551;
    public int anInt1552;
}
