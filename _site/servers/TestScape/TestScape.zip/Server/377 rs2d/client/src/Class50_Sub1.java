// Decompiled by Jad v1.5.8f. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 


public class Class50_Sub1 extends Class50
{

    public void method443()
    {
        if(aClass50_Sub1_1382 == null)
        {
            return;
        } else
        {
            aClass50_Sub1_1382.aClass50_Sub1_1381 = aClass50_Sub1_1381;
            aClass50_Sub1_1381.aClass50_Sub1_1382 = aClass50_Sub1_1382;
            aClass50_Sub1_1381 = null;
            aClass50_Sub1_1382 = null;
            return;
        }
    }

    public Class50_Sub1()
    {
    }

    public Class50_Sub1 aClass50_Sub1_1381;
    public Class50_Sub1 aClass50_Sub1_1382;
    public static int anInt1383;
}
