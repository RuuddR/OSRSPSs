// Decompiled by Jad v1.5.8f. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 


public class Class26
{

    public Class26()
    {
    }

    public byte aByteArray533[];
    public int anInt534;
    public int anInt535;
    public int anInt536;
    public int anInt537;
    public int anInt538;
    public int anInt539;
    public int anInt540;
    public int anInt541;
    public int anInt542;
    public int anInt543;
    public int anInt544;
    public int anInt545;
    public int anInt546;
    public int anInt547;
    public int anInt548;
    public int anInt549;
}
