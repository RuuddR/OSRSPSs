// Decompiled by Jad v1.5.8f. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 


public class Class44
{

    public Class44()
    {
    }

    public int anInt719;
    public int anInt720;
    public int anInt721;
    public int anInt722;
    public int anInt723;
    public Class50_Sub1_Sub4 aClass50_Sub1_Sub4_724;
    public Class50_Sub1_Sub4 aClass50_Sub1_Sub4_725;
    public int anInt726;
    public byte aByte727;
}
