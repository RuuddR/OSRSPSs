// Decompiled by Jad v1.5.8f. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 


public class Class50_Sub1_Sub3 extends Class50_Sub1
{

    public Class50_Sub1_Sub3()
    {
        aBoolean1471 = true;
    }

    public int anInt1467;
    public int anInt1468;
    public int anInt1469;
    public byte aByteArray1470[];
    public boolean aBoolean1471;
}
