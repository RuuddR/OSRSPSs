// Decompiled by Jad v1.5.8f. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 


public class Class4
{

    public Class4()
    {
        anInt105 = 1;
        aBoolean106 = true;
        aBoolean107 = false;
        aBoolean108 = true;
        aBoolean109 = true;
        aBoolean110 = false;
        aBoolean111 = false;
        aBoolean112 = false;
    }

    public static byte aByte102 = 6;
    public static Class4 aClass4Array103[];
    public static int anInt104 = -1;
    public int anInt105;
    public boolean aBoolean106;
    public boolean aBoolean107;
    public boolean aBoolean108;
    public boolean aBoolean109;
    public boolean aBoolean110;
    public boolean aBoolean111;
    public boolean aBoolean112;

}
