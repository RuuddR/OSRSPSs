// Decompiled by Jad v1.5.8f. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 


public class Class39
{

    public Class39()
    {
    }

    public int anInt675;
    public int anInt676;
    public int anInt677;
    public int anInt678;
    public int anInt679;
    public int anInt680;
    public int anInt681;
    public int anInt682;
    public int anInt683;
    public int anInt684;
    public int anInt685;
    public int anInt686;
    public int anInt687;
    public int anInt688;
    public int anInt689;
    public int anInt690;
    public int anInt691;
    public int anInt692;
}
