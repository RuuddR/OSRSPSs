// Decompiled by Jad v1.5.8f. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 


public class Class1
{

    public Class1()
    {
        anIntArray67 = new int[256];
        anIntArray69 = new int[257];
        anIntArray70 = new int[257];
        aBooleanArray73 = new boolean[256];
        aBooleanArray74 = new boolean[16];
        aByteArray75 = new byte[256];
        aByteArray76 = new byte[4096];
        anIntArray77 = new int[16];
        aByteArray78 = new byte[18002];
        aByteArray79 = new byte[18002];
        aByteArrayArray80 = new byte[6][258];
        anIntArrayArray81 = new int[6][258];
        anIntArrayArray82 = new int[6][258];
        anIntArrayArray83 = new int[6][258];
        anIntArray84 = new int[6];
    }

    public final int anInt38 = 4096;
    public final int anInt39 = 16;
    public final int anInt40 = 258;
    public final int anInt41 = 23;
    public final int anInt42 = 1;
    public final int anInt43 = 6;
    public final int anInt44 = 50;
    public final int anInt45 = 4;
    public final int anInt46 = 18002;
    public byte aByteArray47[];
    public int anInt48;
    public int anInt49;
    public int anInt50;
    public int anInt51;
    public byte aByteArray52[];
    public int anInt53;
    public int anInt54;
    public int anInt55;
    public int anInt56;
    public byte aByte57;
    public int anInt58;
    public boolean aBoolean59;
    public int anInt60;
    public int anInt61;
    public int anInt62;
    public int anInt63;
    public int anInt64;
    public int anInt65;
    public int anInt66;
    public int anIntArray67[];
    public int anInt68;
    public int anIntArray69[];
    public int anIntArray70[];
    public static int anIntArray71[];
    public int anInt72;
    public boolean aBooleanArray73[];
    public boolean aBooleanArray74[];
    public byte aByteArray75[];
    public byte aByteArray76[];
    public int anIntArray77[];
    public byte aByteArray78[];
    public byte aByteArray79[];
    public byte aByteArrayArray80[][];
    public int anIntArrayArray81[][];
    public int anIntArrayArray82[][];
    public int anIntArrayArray83[][];
    public int anIntArray84[];
    public int anInt85;
}
