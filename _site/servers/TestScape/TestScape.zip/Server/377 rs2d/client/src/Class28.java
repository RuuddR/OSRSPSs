// Decompiled by Jad v1.5.8f. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 


public class Class28
{

    public Class28()
    {
    }

    public int anInt567;
    public int anInt568;
    public int anInt569;
    public Class50_Sub1_Sub4 aClass50_Sub1_Sub4_570;
    public int anInt571;
    public byte aByte572;
}
