package net.varek.rs2d.packetbuilder;

public interface PacketBuilder {

}
