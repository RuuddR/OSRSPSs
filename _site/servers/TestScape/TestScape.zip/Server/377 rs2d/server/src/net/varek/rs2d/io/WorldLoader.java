/* WorldLoader.java
* Created on 16-Dec-2007, 12:07:32
* To change this template, choose Tools | Template Managerand open the template in the editor.
*/

package net.varek.rs2d.io;

import net.varek.rs2d.model.World;

public interface WorldLoader {
    public void loadWorld(World w);
    }