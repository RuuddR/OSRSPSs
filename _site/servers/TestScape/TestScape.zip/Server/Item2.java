//  This file is free software; you can redistribute it and/or modify it under
//  the terms of the GNU General Public License version 2, 1991 as published by
//  the Free Software Foundation.

//  This program is distributed in the hope that it will be useful, but WITHOUT
//  ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
//  FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more
//  details.

//  A copy of the GNU General Public License can be found at:
//    http://www.gnu.org/licenses/gpl.html

// a collection of item methods
import java.io.*;
public class Item2 
{
public static int runerock[] = {451,451,451,451,451,451,451,451,451,451,451,451,451,451,451,451,451,451,451,451,451,451,451,451,451,451,451,451,451,451,451,451,451,451,451,451,451,451,451,451,451,451,451,451,451,451,451,451,451,451,451,451,451,451,451,451,451,451,451,451,451,451,451,451,451,451,451,451,451,451,451,451,451,451,451,451,1481,451,451,451,451,451,451,451,451,451,451,451,451,451,451,451,451,451,451,451,451,451,451,451,451,451,451,451,451,451,451,451,451,451,451,451,451,451,451,451,451,451,451,451,451,451,451,451,451,451,451,451,451,451,451,451,451,451,451,451,451,451,451,451,451,451,451,451,451,451,451,451,451,451,451,451,451,451,451,451,451,451,451,451,451,451,451,451,451,451,451,451,451,451,451,451,451,451,451,451,451,451,451,451,451,451,451,451,451,451,451,451,451,451,451,451,451,451,451,451,451,451,451,451,451,451};

    public static int randomRuneRock()
    {
    	return runerock[(int)(Math.random()*runerock.length)];
    }	

public static int KBD[] = {4734,1575,3140,1575,1575,989,989,989,989,4119,4119,4119,4119,4119,2503,2503,2503,2503,2503,2503,2503,2503,2503,1249,1846,1846,1846,4158,4158,4158,4158,4158,2476,2476,2476,2476,2476,2476,2476,2476,2476,2476,2476,2476,2476,2476,2476,2476,2476,2476,2476,1263,1635,1635,1635,1635,1635,1635,1635,1635,1635,1635,1635,1635,1635,1635,1635,1635,1635,1635,1635,1635,1635,1635,1635,1635,1635,1635,1635,1635,1635,1580,5013,5013,5013,1611,1611,1611,1611,1611,1611,1611,1611,1611,1611,1611,1611,2599,2599,2599,2599,2599,2599,4170,4170,4170,1641,1641,1641,1641,1641,1641,1641,1641,1641,1641,1641,1641,1641,1641,1641,1641,1641,1641,1641,1641,1641,1641,1641,1641,1641,1641,1641,1641,1641,1641,1641,1641,1635,1635,1635,1635,1635,1635,1635,1635,1635,1635,1635,1635,1635,1635,1635,1635,1635,1635,2683,2683};

    public static int randomKBD()
    {
    	return KBD[(int)(Math.random()*KBD.length)];
    }	

public static int fish[] = {385,385,379,379,379,379,379};

    public static int randomFish()
    {
    	return fish[(int)(Math.random()*fish.length)];
    }	

public static int abyssal[] = {389,385,389,385,989,989,989,989,1079,1093,1073,1073,1073,1113,1113,1109,1109,1123,1123,1127,995,995,995,995,1149,1149,1163,1163,1163,1187,1201,1213,1213,1213,1213,1213,4151,4151,4151,1215,1215,1249,1303,1303,1305,1289,1333,1333,1333,1333,1359,1359,1359,1359,1359,1371,1373,1371,1371,1639,1639,1645,1643,1643,1704,1704,1712,1731,1731,1731,3140};

    public static int randomAbyssal()
    {
    	return abyssal[(int)(Math.random()*abyssal.length)];
    }	
public static int dragon[] = {3140,3140,3140,3140,1187,4151,4151,4153,1187,1187,1187,1149,1149,1149,1149,4087,4087,4087,4087,4089,4091,4093,4095,4097,4099,4101,4103,4105,4107,4109,4111,4113,4115,4117,4089,4091,4093,4095,4097,4099,4101,4103,4105,4107,4109,4111,4113,4115,4117,3749,3749,3749,3751,3751,3751,3753,3753,3753,3755,3755,3755};

    public static int randomDragon()
    {
	return dragon[(int)(Math.random()*dragon.length)];
    }
public static int wknight[] = {1293,4131,4131,4131,4129,989,989,989,989,4129,4153,4153,1281,1281,1249,1249,1462,1462,1052,1052,1077,1077,1125,1165,1195,1195,995,1165,1049,1293,1293,1293,1293,1617,1617,1619,1619,1621,1621,1623,1623,3749,3749,3749,3751,3751,3751,3753,3753,3753,3755,3755,3755,4089,4091,4093,4095,4097,4099,4101,4103,4105,4107,4109,4111,4113,4115,4117,4089,4091,4093,4095,4097,4099,4101,4103,4105,4107,4109,4111,4113,4115,4117};

    public static int randomWknight()
    {
	return wknight[(int)(Math.random()*wknight.length)];
    }
public static int kofardy[] = {385,385,385,385,385,385,7158};
   
    public static int randomKofardy()
    {
	return kofardy[(int)(Math.random()*kofardy.length)];
    }
public static int crystal[] = {1048,1046,1050,4151};
    
    public static int randomCrystal()
    {
	return crystal[(int)(Math.random()*crystal.length)];
    }
public static int barrowsitem[] = {4708,4710,4712,4714,4716,4718,4720,4722,4724,4726,4728,4730,4732,4734,4736,4738,4745,4747,4749,4751,4753,4755,4757,4759};

    public static int randomBarrowsitem()
    {
	return barrowsitem[(int)(Math.random()*barrowsitem.length)];
    }
public static int guthan[] = {385,385,385,385,385,385,989,989,385,385,995,995,995,995,4724,4726,4728,4730};
	public static int randomGuthan()
	{
	return guthan[(int)(Math.random()*guthan.length)];
	}
public static int dharok[] = {385,385,385,385,385,989,989,385,385,385,995,995,995,995,4716,4718,4720,4722};
	public static int randomDharok()
	{
	return dharok[(int)(Math.random()*dharok.length)];
	}
public static int verac[] = {385,385,385,385,385,385,385,989,989,385,995,995,995,995,4753,4755,4757,4759};
	public static int randomVerac()
	{
	return verac[(int)(Math.random()*verac.length)];
	}
public static int ahrims[] = {385,385,385,385,385,385,989,989,385,385,995,995,995,995,4708,4710,4712,4714};
	public static int randomAhrims()
	{
	return ahrims[(int)(Math.random()*ahrims.length)];
	}
public static int torag[] = {385,385,385,385,385,385,385,989,989,385,995,995,995,995,4745,4747,4749,4751};
	public static int randomTorag()
	{
	return torag[(int)(Math.random()*torag.length)];
	}
public static int karil[] = {385,385,385,385,385,385,385,989,989,385,995,995,995,995,4732,4734,4736,4738};
	public static int randomKaril()
	{
	return karil[(int)(Math.random()*karil.length)];
	}
public static int herby[] = {221,221,221,221,221,221,221,221,221,221,221,221,221,221,223,223,223,223,223,225,225,225,225,227,227,227,227,227,227,227,227,227,227,227,227,227,227,227,227,227,227,227,227,227,227,227,227,227,227,229,231,229,229,231,229,229,233,233,233,235,233,235,235,235,237,237,237,235,237,239,239,239,239,241,241,241,243,243,243,243,243,245,245,245,245,245,245,245,247,247,247,247,247,247,249,249,249,249,249,249,249,249,249,249,249,249,249,249,249,249,249,249,249,251,251,251,251,251,251,253,253,253,255,257,257,259,259,261,261,263,263,263,265,265,267,269,269};

    public static int randomHerby()
    {
    	return herby[(int)(Math.random()*herby.length)];
    }	

}
