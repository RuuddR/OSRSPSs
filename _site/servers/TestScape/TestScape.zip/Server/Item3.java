import java.io.*;
public class Item3 {

public static int slayeritems85[] = {1079,1079,1091,1091,1091,1091,1089,1089,989,989,989,989,1113,7158,1149,1187,1093,1093,1113,1113,1113,1111,1111,1111,1147,1147,1147,1159,1159,1159,1161,1161,1161,1163,1163,1163,1183,1183,1183,1185,1185,1201};

    public static int randomSlayeritem85()
    {
    	return slayeritems85[(int)(Math.random()*slayeritems85.length)];
    }

public static int chaos[] = {1161,1161,2581,2581,2581,2581,2366,2368,2577,2577,2577,2577,2577,1073,1073,1073,1073,1123,1123,1123,1161,7158,7158,1123,1123,1073,1073,1073,1073,7158,7158,1161,4151,4151,4151,1187,1187,1333,1333,1113,4087,1123,1149,1149,1123,1123,4132,4132,1073,1073,4132,4132,1073,1073,4132,4132,1200,1073,1073,1073,1200,1200,1123,1123,1123,1073,1073,1073,1073};

    public static int randomchaos()
    {
    	return chaos[(int)(Math.random()*chaos.length)];
    }

public static int capturedgoblin[] = {1241,1241,995,995,995,995,995,1037,1037,2633,2633,2635,2635,2637,2637,2631,2631,2651,2651,2645,2645,2647,2647,1241,1241,1241};
    
    public static int randomCapturedgoblin()
    {
	return capturedgoblin[(int)(Math.random()*capturedgoblin.length)];
    }

public static int tyrasguard[] = {995,995,995,995,995,1089,1089,1089,1089,1089,1089,1089,1079,1052,1052,2366,2368,1079,1079,1113,1113,1127,1127,1127,1149,1161,1161,1161,1163,1163,1185,1185,1201,1201,1199,1199,1199,1301,1301,1301,1303,1303,1319,1319,1319,1373,1373,1373,1373,1377,1401,1403,1405,1407,1401,1403,1405,1407,1401,1403,989,989,989,989,1405,1407,1401,1403,1405,1407};
    
    public static int randomTyrasguard()
    {
	return tyrasguard[(int)(Math.random()*tyrasguard.length)];
    }

public static int highdemon[] = {1073,1073,1073,1073,1073,1113,1111,1111,1111,1111,1111,1123,1123,1123,1127,1149,1147,1147,1161,1161,1161,1161,1161,1161,1199,1199,1199,1199,1199,1194,1194,1333,1333,2366,2368};
    
    public static int randomHighdemon()
    {
	return highdemon[(int)(Math.random()*highdemon.length)];
    }
public static int chicken[] = {526,526,526,526,526,526,530,530,532,532,532,532,534,534,534,534,536,536,536,536,536,4830,4830,4830,4832,4832,4812,4832,4812};
    public static int randomChicken()
    {
	return chicken[(int)(Math.random()*chicken.length)];
    }
public static int guard[] = {995,995,2583,2583,2572,2585,2587,2589,2591,2593,2595,2597,995,995,2579,2579};

    public static int randomGuard()
    {
    	return guard[(int)(Math.random()*guard.length)];
    }
public static int seed[] = {5105,5106,5096,5097,5098,5099,5100,5101,5012,5103,5104,5281,5282,5291,5292,5293,5294,5295,5296,5297,5298,5299,5300,5301,5302,5203,5304,5305,5306,5307,5308,5309,5310,5311,5320,5321,5322,5323,5324};
	public static int randomSeed()
	{
		return seed[(int)(Math.random()*seed.length)];
	}
}