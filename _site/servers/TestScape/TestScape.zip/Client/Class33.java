public class Class33
{

    public Class33()
    {
    }

    int anInt602;
    int anInt603;
    int anInt604;
    int anInt605;
}
