import sign.signlink;

final class Class30_Sub2_Sub4_Sub2 extends Class30_Sub2_Sub4
{

    public final Class30_Sub2_Sub4_Sub6 method444(int i)
    {
        Class8 class8 = Class8.method198(anInt1558);
        if(i != 4016)
            throw new NullPointerException();
        else
            return class8.method201(anInt1559);
    }

    Class30_Sub2_Sub4_Sub2()
    {
    }

    public int anInt1558;
    public int anInt1559;
}
