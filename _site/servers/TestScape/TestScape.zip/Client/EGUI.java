import java.awt.BorderLayout;
import java.awt.Cursor;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.*;

public class EGUI
{
    public static void main(String args[])
    {
                    client.main(new String[] {
                "127.0.0.1", "127.0.0.1", "127.0.0.1"
            });
        }
    }
