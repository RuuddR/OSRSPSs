/*



*/

public final class Class26
{

    public Class26()
    {
    }

    int anInt499;
    int anInt500;
    int anInt501;
    int anInt502;
    int anInt503;
    public Class30_Sub2_Sub4 aClass30_Sub2_Sub4_504;
    public int anInt505;
    byte aByte506;
}
