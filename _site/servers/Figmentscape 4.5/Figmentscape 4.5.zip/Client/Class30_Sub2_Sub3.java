/*



*/

public class Class30_Sub2_Sub3 extends Class30_Sub2
{

    public Class30_Sub2_Sub3()
    {
        aBoolean1422 = true;
    }

    int anInt1419;
    byte aByteArray1420[];
    int anInt1421;
    boolean aBoolean1422;
    int anInt1423;
}
