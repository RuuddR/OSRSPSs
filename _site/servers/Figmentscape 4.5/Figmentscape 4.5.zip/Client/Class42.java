/*



*/

public class Class42
{

    public void method548(int i)
    {
    }

    public Class42()
    {
        aBoolean715 = true;
    }

    private boolean aBoolean715;
}
