/*



*/

final class Class30_Sub3 extends Class30
{

    public Class30_Sub3(int i, int j, int k)
    {
        anInt1306 = -589;
        aClass28Array1318 = new Class28[5];
        anIntArray1319 = new int[5];
        anInt1310 = anInt1307 = i;
        anInt1308 = j;
        anInt1309 = k;
    }

    private int anInt1306;
    int anInt1307;
    int anInt1308;
    int anInt1309;
    int anInt1310;
    public Class43 aClass43_1311;
    public Class40 aClass40_1312;
    Class10 aClass10_1313;
    Class26 aClass26_1314;
    Class49 aClass49_1315;
    Class3 aClass3_1316;
    int anInt1317;
    Class28 aClass28Array1318[];
    int anIntArray1319[];
    int anInt1320;
    int anInt1321;
    boolean aBoolean1322;
    boolean aBoolean1323;
    boolean aBoolean1324;
    int anInt1325;
    int anInt1326;
    int anInt1327;
    int anInt1328;
    Class30_Sub3 aClass30_Sub3_1329;
}
