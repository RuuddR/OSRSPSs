#!/bin/bash 

# Tested with:  SuSE Linux 10.0
# Requires java path be stored in $PATH

# Usage:
# Enter the following in terminal before first usage:
# "chmod +x compile.sh && chmod +x run.sh

javac -classpath . -d bin *.java -g


