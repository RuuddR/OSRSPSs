
public class Class30
{

    public void method329()
    {
        if(aClass30_550 == null)
        {
            return;
        } else
        {
            aClass30_550.aClass30_549 = aClass30_549;
            aClass30_549.aClass30_550 = aClass30_550;
            aClass30_549 = null;
            aClass30_550 = null;
            return;
        }
    }

    public Class30()
    {
        aBoolean547 = true;
    }

    private boolean aBoolean547;
    public long aLong548;
    public Class30 aClass30_549;
    Class30 aClass30_550;
    public static boolean aBoolean551;
}
