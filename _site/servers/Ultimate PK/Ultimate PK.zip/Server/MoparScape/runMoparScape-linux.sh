#!/bin/sh
java -noverify -Xmx500m -cp .:./MoparScape.jar:./HybridScape: Bot 0
#param 0 for highmem, 1 for lowmem
