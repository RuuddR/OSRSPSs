#!/bin/sh
(cd Scripts;
 javac -cp .:./../../MoparScape.jar: *.java)
