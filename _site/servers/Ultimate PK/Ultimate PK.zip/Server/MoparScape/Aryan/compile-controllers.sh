#!/bin/sh
(cd Controllers;
 javac -cp .:./../../MoparScape.jar: *.java)