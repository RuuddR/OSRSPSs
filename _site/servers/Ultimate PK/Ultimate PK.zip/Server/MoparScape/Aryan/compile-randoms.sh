#!/bin/sh
(cd Randoms;
 javac -cp .:./../../MoparScape.jar: *.java)
