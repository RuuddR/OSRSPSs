#!/bin/sh
rm */*.class
