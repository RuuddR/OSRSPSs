#!/bin/sh
javac -cp .:./../MoparScape.jar: *.java
