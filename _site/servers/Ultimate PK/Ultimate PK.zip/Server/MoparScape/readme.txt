
to start moparscape in windows double click runMoparScape.bat

to start moparscape in linux double click runMoparScape-linux.sh

to start moparscape in Mac double click MoparScape.jar(you wont be able to run the server from the button) or runMoparScape-linux.sh

for a list of item, npc, and object ids look in the all_IDs folder