/*



*/

public final class Class10
{

    public Class10()
    {
    }

    int anInt273;
    int anInt274;
    int anInt275;
    int anInt276;
    int anInt277;
    public Class30_Sub2_Sub4 aClass30_Sub2_Sub4_278;
    public Class30_Sub2_Sub4 aClass30_Sub2_Sub4_279;
    public int anInt280;
    byte aByte281;
}
