/*



FILE: LEVELS.
*/

public class Class45
{

    public static int anInt733 = 25;
    public static String aStringArray734[] = {
        "attack", "defence", "strength", "hitpoints", "ranged", "prayer", "magic", "cooking", "woodcutting", "fletching",
        "fishing", "firemaking", "crafting", "smithing", "mining", "herblore", "agility", "thieving", "slayer", "farming",
        "runecraft", "construction", "hunting", "summoning", "-unused-"
    };
    public static boolean aBooleanArray735[] = {
        true, true, true, true, true, true, true, true, true, true,
        true, true, true, true, true, true, true, true, true, false,
        true, true, true, true, false
    };

}
