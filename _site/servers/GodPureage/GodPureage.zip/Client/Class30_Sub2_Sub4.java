/*



*/

import sign.signlink;

public class Class30_Sub2_Sub4 extends Class30_Sub2
{

    public void method443(int i, int j, int k, int l, int i1, int j1, int k1,
            int l1, int i2)
    {
        Class30_Sub2_Sub4_Sub6 class30_sub2_sub4_sub6 = method444(4016);
        if(class30_sub2_sub4_sub6 != null)
        {
            anInt1426 = ((Class30_Sub2_Sub4) (class30_sub2_sub4_sub6)).anInt1426;
            class30_sub2_sub4_sub6.method443(i, j, k, l, i1, j1, k1, l1, i2);
        }
    }

    public Class30_Sub2_Sub4_Sub6 method444(int i)
    {
        if(i != 4016)
            anInt1424 = -185;
        return null;
    }

    public Class30_Sub2_Sub4()
    {
        anInt1424 = 923;
        anInt1426 = 1000;
    }

    private int anInt1424;
    Class33 aClass33Array1425[];
    public int anInt1426;
    public static boolean aBoolean1427;
}
