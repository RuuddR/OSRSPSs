/*



*/

public final class Class28
{

    public Class28()
    {
    }

    int anInt517;
    int anInt518;
    int anInt519;
    int anInt520;
    public Class30_Sub2_Sub4 aClass30_Sub2_Sub4_521;
    public int anInt522;
    int anInt523;
    int anInt524;
    int anInt525;
    int anInt526;
    int anInt527;
    int anInt528;
    public int anInt529;
    byte aByte530;
}
