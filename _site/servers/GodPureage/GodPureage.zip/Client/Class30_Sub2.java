/*



*/

public class Class30_Sub2 extends Class30
{

    public void method330()
    {
        if(aClass30_Sub2_1304 == null)
        {
            return;
        } else
        {
            aClass30_Sub2_1304.aClass30_Sub2_1303 = aClass30_Sub2_1303;
            aClass30_Sub2_1303.aClass30_Sub2_1304 = aClass30_Sub2_1304;
            aClass30_Sub2_1303 = null;
            aClass30_Sub2_1304 = null;
            return;
        }
    }

    public Class30_Sub2()
    {
    }

    public Class30_Sub2 aClass30_Sub2_1303;
    Class30_Sub2 aClass30_Sub2_1304;
    public static int anInt1305;
}
