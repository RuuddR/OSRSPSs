/*



*/

public class Class21
{

    public Class21()
    {
    }

    public byte aByteArray368[];
    public int anInt369;
    public int anInt370;
    public int anInt371;
    public int anInt372;
    public int anInt373;
    public int anInt374;
    public int anInt375;
    public int anInt376;
    public int anInt377;
    public int anInt378;
    public int anInt379;
    public int anInt380;
    public int anInt381;
    public int anInt382;
    public int anInt383;
    public int anInt384;
}
