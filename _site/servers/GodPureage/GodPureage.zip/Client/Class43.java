/*



*/

final class Class43
{

    public Class43(int i, int j, int k, int l, int i1, int j1, boolean flag)
    {
        aBoolean721 = true;
        anInt716 = i;
        anInt717 = j;
        anInt718 = k;
        anInt719 = l;
        anInt720 = i1;
        anInt722 = j1;
        aBoolean721 = flag;
    }

    int anInt716;
    int anInt717;
    int anInt718;
    int anInt719;
    int anInt720;
    boolean aBoolean721;
    int anInt722;
}
