final class Class3
{

    Class3()
    {
    }

    int anInt45;
    int anInt46;
    int anInt47;
    Class30_Sub2_Sub4 aClass30_Sub2_Sub4_48;
    Class30_Sub2_Sub4 aClass30_Sub2_Sub4_49;
    Class30_Sub2_Sub4 aClass30_Sub2_Sub4_50;
    int anInt51;
    int anInt52;
}
