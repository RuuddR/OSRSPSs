class Class32
{

    Class32()
    {
        anIntArray583 = new int[256];
        anIntArray585 = new int[257];
        anIntArray586 = new int[257];
        aBooleanArray589 = new boolean[256];
        aBooleanArray590 = new boolean[16];
        aByteArray591 = new byte[256];
        aByteArray592 = new byte[4096];
        anIntArray593 = new int[16];
        aByteArray594 = new byte[18002];
        aByteArray595 = new byte[18002];
        aByteArrayArray596 = new byte[6][258];
        anIntArrayArray597 = new int[6][258];
        anIntArrayArray598 = new int[6][258];
        anIntArrayArray599 = new int[6][258];
        anIntArray600 = new int[6];
    }

    final int anInt554 = 4096;
    final int anInt555 = 16;
    final int anInt556 = 258;
    final int anInt557 = 23;
    final int anInt558 = 1;
    final int anInt559 = 6;
    final int anInt560 = 50;
    final int anInt561 = 4;
    final int anInt562 = 18002;
    byte aByteArray563[];
    int anInt564;
    int anInt565;
    int anInt566;
    int anInt567;
    byte aByteArray568[];
    int anInt569;
    int anInt570;
    int anInt571;
    int anInt572;
    byte aByte573;
    int anInt574;
    boolean aBoolean575;
    int anInt576;
    int anInt577;
    int anInt578;
    int anInt579;
    int anInt580;
    int anInt581;
    int anInt582;
    int anIntArray583[];
    int anInt584;
    int anIntArray585[];
    int anIntArray586[];
    public static int anIntArray587[];
    int anInt588;
    boolean aBooleanArray589[];
    boolean aBooleanArray590[];
    byte aByteArray591[];
    byte aByteArray592[];
    int anIntArray593[];
    byte aByteArray594[];
    byte aByteArray595[];
    byte aByteArrayArray596[][];
    int anIntArrayArray597[][];
    int anIntArrayArray598[][];
    int anIntArrayArray599[][];
    int anIntArray600[];
    int anInt601;
}
