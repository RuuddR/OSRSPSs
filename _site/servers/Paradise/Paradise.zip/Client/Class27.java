/*



*/

public class Class27
{

    public Class27()
    {
        anInt509 = 1;
        aBoolean510 = true;
        aBoolean511 = false;
        aBoolean512 = true;
        aBoolean513 = true;
        aBoolean514 = false;
        aBoolean515 = false;
        aBoolean516 = false;
    }

    public static Class27 aClass27Array507[];
    public static int anInt508 = -1;
    public int anInt509;
    public boolean aBoolean510;
    public boolean aBoolean511;
    public boolean aBoolean512;
    public boolean aBoolean513;
    public boolean aBoolean514;
    public boolean aBoolean515;
    public boolean aBoolean516;

}
