package net.paradise.game.npc;

public class NPCList
{

	public int npcId;
	public String npcName;
	public int npcCombat;
	public int npcHealth;

	public NPCList(int _npcId)
	{
		npcId = _npcId;
	}

}