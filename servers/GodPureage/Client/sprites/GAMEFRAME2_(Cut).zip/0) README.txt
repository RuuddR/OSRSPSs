Firstly, Thanks for using the RS2 Gameframe cutter. :)

This Gameframe Cutter cuts your gameframe into sprites which fit a Modified RS2 #317 Client.

The contents of the Cut Gameframe are as follows:
 � BACKBASE1 0
 � BACKBASE2 0
 � BACKHMID1 0
 � BACKHMID2 0
 � BACKLEFT2 0
 � BACKRIGHT1 0
 � BACKRIGHT2 0
 � BACKTOP1 0
 � BACKVMID1 0
 � BACKVMID2 0
 � BACKVMID3 0
 � CHATBACK 0
 � INVBACK 0
 � MAPBACK 0

For your client to sucessfully use the gameframe, you must have custom loading of those sprites enabled.

-----

If you need to contact me for any reason, you can:
 � Send a Personal Message to Unborn, at http://rune-server.org/,
 � Send a Personal Message to Unborn, at http://unscape.ben-corbett.com/,
 � Send an E-mail to ben_mclarenf1@yahoo.com,
 � Add ben_v4@hotmail.com to your Windows Live / Yahoo Messenger, and contact me there.

-----

If you find and bugs in the Gameframe Cutter, please report it using any of the contact methods above.

-----

Thanks,
Unborn